
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'LowCostLidar' 
 * Target:  'LowCostLidar' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "MKL05Z4.h"



#endif /* RTE_COMPONENTS_H */
